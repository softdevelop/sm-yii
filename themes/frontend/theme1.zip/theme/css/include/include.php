

/*==================================================================================================
    ANIMATIONS
==================================================================================================*/


/*--------------------------------------------------------------------------------------------------
    ROTATE LEFT
--------------------------------------------------------------------------------------------------*/

@keyframes rotate_left {
    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(-360deg);
    }
}

@-webkit-keyframes rotate_left {
    from {
        -webkit-transform: rotate(0deg);
    }

    to {
        -webkit-transform: rotate(-360deg);
    }
}

@-moz-keyframes rotate_left {
    from {
        -moz-transform: rotate(0deg);
    }

    to {
        -moz-transform: rotate(-360deg);
    }
}

@-o-keyframes rotate_left {
    from {
        -o-transform: rotate(0deg);
    }

    to {
        -o-transform: rotate(-360deg);
    }
}


/*--------------------------------------------------------------------------------------------------
    ROTATE RIGHT
--------------------------------------------------------------------------------------------------*/

@keyframes rotate_right {
    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes rotate_right {
    from {
        -webkit-transform: rotate(0deg);
    }

    to {
        -webkit-transform: rotate(360deg);
    }
}

@-moz-keyframes rotate_right {
    from {
        -moz-transform: rotate(0deg);
    }

    to {
        -moz-transform: rotate(360deg);
    }
}

@-o-keyframes rotate_right {
    from {
        -o-transform: rotate(0deg);
    }

    to {
        -o-transform: rotate(360deg);
    }
}


/*--------------------------------------------------------------------------------------------------
    SHAKE VERTICALLY
--------------------------------------------------------------------------------------------------*/

@keyframes shake_vertically {
    0% {
        transform: translate(0, 0);
    }

    25% {
        transform: translate(0, -5px);
    }

    75% {
        transform: translate(0, 5px);
    }

    100% {
        transform: translate(0, 0);
    }
}

@-webkit-keyframes shake_vertically {
    0% {
        -webkit-transform: translate(0, 0);
    }

    25% {
        -webkit-transform: translate(0, -5px);
    }

    75% {
        -webkit-transform: translate(0, 5px);
    }

    100% {
        -webkit-transform: translate(0, 0);
    }
}

@-moz-keyframes shake_vertically {
    0% {
        -moz-transform: translate(0, 0);
    }

    25% {
        -moz-transform: translate(0, -5px);
    }

    75% {
        -moz-transform: translate(0, 5px);
    }

    100% {
        -moz-transform: translate(0, 0);
    }
}

@-o-keyframes shake_vertically {
    0% {
        -o-transform: translate(0, 0);
    }

    25% {
        -o-transform: translate(0, -5px);
    }

    75% {
        -o-transform: translate(0, 5px);
    }

    100% {
        -o-transform: translate(0, 0);
    }
}


/*--------------------------------------------------------------------------------------------------
    SHAKE HORIZONTALLY
--------------------------------------------------------------------------------------------------*/

@keyframes shake_horizontally {
    0% {
        transform: translate(0, 0);
    }

    25% {
        transform: translate(-5px, 0);
    }

    75% {
        transform: translate(5px, 0);
    }

    100% {
        transform: translate(0, 0);
    }
}

@-webkit-keyframes shake_horizontally {
    0% {
        -webkit-transform: translate(0, 0);
    }

    25% {
        -webkit-transform: translate(-5px, 0);
    }

    75% {
        -webkit-transform: translate(5px, 0);
    }

    100% {
        -webkit-transform: translate(0, 0);
    }
}

@-moz-keyframes shake_horizontally {
    0% {
        -moz-transform: translate(0, 0);
    }

    25% {
        -moz-transform: translate(-5px, 0);
    }

    75% {
        -moz-transform: translate(5px, 0);
    }

    100% {
        -moz-transform: translate(0, 0);
    }
}

@-o-keyframes shake_horizontally {
    0% {
        -o-transform: translate(0, 0);
    }

    25% {
        -o-transform: translate(-5px, 0);
    }

    75% {
        -o-transform: translate(5px, 0);
    }

    100% {
        -o-transform: translate(0, 0);
    }
}


/*--------------------------------------------------------------------------------------------------
    PULSATE
--------------------------------------------------------------------------------------------------*/

@keyframes pulsate {
    0% {
        transform: scale(1);
    }

    25% {
        transform: scale(1.05);
    }

    75% {
        transform: scale(0.95);
    }

    100% {
        transform: scale(1);
    }
}

@-webkit-keyframes pulsate {
    0% {
        -webkit-transform: scale(1);
    }

    25% {
        -webkit-transform: scale(1.05);
    }

    75% {
        -webkit-transform: scale(0.95);
    }

    100% {
        -webkit-transform: scale(1);
    }
}

@-moz-keyframes pulsate {
    0% {
        -moz-transform: scale(1);
    }

    25% {
        -moz-transform: scale(1.05);
    }

    75% {
        -moz-transform: scale(0.95);
    }

    100% {
        -moz-transform: scale(1);
    }
}

@-o-keyframes pulsate {
    0% {
        -o-transform: scale(1);
    }

    25% {
        -o-transform: scale(1.05);
    }

    75% {
        -o-transform: scale(0.95);
    }

    100% {
        -o-transform: scale(1);
    }
}